"""test_dataset dataset."""

import os  # <-- Needed for os.path.expanduser
import tensorflow_datasets as tfds
import tensorflow as tf


class Builder(tfds.core.GeneratorBasedBuilder):
    """DatasetBuilder for test_dataset dataset."""

    VERSION = tfds.core.Version('1.0.0')
    RELEASE_NOTES = {
        '1.0.0': 'Initial release.',
    }

    def _info(self):
        return self.dataset_info_from_configs(
            features=tfds.features.FeaturesDict({
                "episode_metadata": tfds.features.FeaturesDict({
                    "language_command": tfds.features.Text(),
                }),
                "steps": tfds.features.Sequence({
                    "state": tfds.features.Tensor(shape=(9,), dtype=tf.float32),
                    "action": tfds.features.Tensor(shape=(8,), dtype=tf.float32),
                    "reward": tfds.features.Scalar(dtype=tf.int64),
                    "is_first": tfds.features.Scalar(dtype=tf.bool),
                    "is_terminal": tfds.features.Scalar(dtype=tf.bool),
                }),
            }),
            supervised_keys=None,
            homepage="https://dataset-homepage/",
        )


    def _split_generators(self, dl_manager):
        """Returns SplitGenerators using a manually specified tfrecord file."""
        tfrecord_path = os.path.expanduser('~/octo_ws/octo/record_dataset/dataset/tomato_dataset.tfrecord')
        return {
            "train": self._generate_examples(tfrecord_path=tfrecord_path),
        }

    def _generate_examples(self, tfrecord_path):
        raw_dataset = tf.data.TFRecordDataset(tfrecord_path)

        episode_steps = []
        language_command = None
        episode_index = 0

        for raw_record in raw_dataset:
            example = tf.train.Example()
            example.ParseFromString(raw_record.numpy())
            f = example.features.feature

            step = {
                'state': list(f['state'].float_list.value),
                'action': list(f['action'].float_list.value),
                'reward': f['reward'].int64_list.value[0],
                'is_first': bool(f['is_first'].int64_list.value[0]),
                'is_terminal': bool(f['is_terminal'].int64_list.value[0]),
            }

            if language_command is None:
                language_command = f['language_command'].bytes_list.value[0].decode('utf-8')

            episode_steps.append(step)

            if step['is_terminal']:
                yield str(episode_index), {
                    'episode_metadata': {
                        'language_command': language_command,
                    },
                    'steps': episode_steps,
                }
                episode_steps = []
                language_command = None
                episode_index += 1

